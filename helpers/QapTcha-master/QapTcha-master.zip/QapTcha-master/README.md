# Readme

Full documentation on [MyJqueryPlugins](http://www.myjqueryplugins.com/QapTcha)

Demonstration on [QapTcha demonstration page](http://www.myjqueryplugins.com/QapTcha/demo)